
#!/usr/bin/env python

import sys



current_rating = None

total = 0



for line in sys.stdin:

    line = line.strip()

    if not line:

        continue



    rating, count = line.split("\t")

    rating = int(rating)

    count = int(count)



    if current_rating == rating:

        total += count

    else:

        if current_rating is not None:

            print("%d\t%d" % (current_rating, total))

        current_rating = rating

        total = count



if current_rating is not None:

    print("%d\t%d" % (current_rating, total))

