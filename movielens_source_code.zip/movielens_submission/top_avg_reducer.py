
#!/usr/bin/env python

import sys



emitted = 0



for line in sys.stdin:

    line = line.rstrip("\n")

    parts = line.split("\t", 1)

    if len(parts) != 2:

        continue



    fields = parts[1].split("|")

    if len(fields) != 4:

        continue



    if emitted < 10:

        print("%s\t%s\t%s\t%s" %

              (fields[0], fields[1], fields[2], fields[3]))

        emitted += 1

    else:

        break

