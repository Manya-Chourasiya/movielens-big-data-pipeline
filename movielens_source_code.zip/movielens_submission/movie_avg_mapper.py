
#!/usr/bin/env python

import sys



for line in sys.stdin:

    fields = line.strip().split()

    if len(fields) >= 3:

        try:

            movie_id = int(fields[1])

            rating = float(fields[2])

            print("%d\t%.1f,1" % (movie_id, rating))

        except ValueError:

            continue

