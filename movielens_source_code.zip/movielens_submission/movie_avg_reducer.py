
#!/usr/bin/env python

import sys



current_movie = None

rating_sum = 0.0

rating_count = 0



def emit(movie_id, total, count):

    if movie_id is not None and count >= 50:

        print("%d\t%.4f\t%d" % (movie_id, total / count, count))



for line in sys.stdin:

    line = line.strip()

    if not line:

        continue



    movie_id, value = line.split("\t")

    movie_id = int(movie_id)

    rating, count = value.split(",")

    rating = float(rating)

    count = int(count)



    if movie_id == current_movie:

        rating_sum += rating

        rating_count += count

    else:

        emit(current_movie, rating_sum, rating_count)

        current_movie = movie_id

        rating_sum = rating

        rating_count = count



emit(current_movie, rating_sum, rating_count)

