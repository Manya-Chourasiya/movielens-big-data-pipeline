
#!/usr/bin/env python



import sys



for line in sys.stdin:

    line = line.strip()

    if not line:

        continue



    fields = line.split('\t')



    try:

        movie_id = fields[0]

        title = fields[1]

        rating_count = int(fields[2])

        average_rating = float(fields[3])



        if average_rating >= 4.0:

            label = "Excellent"

        elif average_rating >= 3.5:

            label = "Good"

        elif average_rating >= 3.0:

            label = "Average"

        else:

            label = "Poor"



        print("%s\t%s\t%d\t%.4f\t%s" % (

            movie_id, title, rating_count, average_rating, label

        ))

    except (ValueError, IndexError):

        continue

