
#!/usr/bin/env python

import sys



for line in sys.stdin:

    fields = line.rstrip("\n").split("\t")

    if len(fields) != 4:

        continue



    try:

        movie_id = int(fields[0])

        title = fields[1]

        avg_rating = float(fields[2])

        count = int(fields[3])

        sort_key = 50000 - int(round(avg_rating * 10000))

        print("%05d\t%d|%s|%.4f|%d" %

              (sort_key, movie_id, title, avg_rating, count))

    except ValueError:

        continue

