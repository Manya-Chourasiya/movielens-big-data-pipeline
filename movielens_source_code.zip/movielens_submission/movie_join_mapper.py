
#!/usr/bin/env python

import sys



for line in sys.stdin:

    line = line.rstrip("\n")

    if not line:

        continue



    # Ratings input: movie_id, average_rating, count

    fields = line.split("\t")

    if len(fields) == 3:

        try:

            movie_id = int(fields[0])

            avg_rating = float(fields[1])

            count = int(fields[2])

            print("%d\tAVG|%.4f|%d" % (movie_id, avg_rating, count))

        except ValueError:

            continue

        continue



    # Movie metadata input: pipe-delimited movie_id|title|...

    fields = line.split("|")

    if len(fields) >= 2:

        try:

            movie_id = int(fields[0])

            title = fields[1]

            print("%d\tMOVIE|%s" % (movie_id, title))

        except ValueError:

            continue

