
#!/usr/bin/env python

import sys



current_movie = None

title = None

avg_rating = None

rating_count = None



def emit():

    if current_movie is not None and title is not None and avg_rating is not None:

        print("%d\t%s\t%.4f\t%d" %

              (current_movie, title, avg_rating, rating_count))



for line in sys.stdin:

    line = line.rstrip("\n")

    if not line:

        continue



    movie_id_text, value = line.split("\t", 1)

    movie_id = int(movie_id_text)



    if current_movie != movie_id:

        emit()

        current_movie = movie_id

        title = None

        avg_rating = None

        rating_count = None



    if value.startswith("MOVIE|"):

        title = value.split("|", 1)[1]

    elif value.startswith("AVG|"):

        parts = value.split("|")

        avg_rating = float(parts[1])

        rating_count = int(parts[2])



emit()

