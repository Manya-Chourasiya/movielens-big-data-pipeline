
#!/usr/bin/env python

import sys



for line in sys.stdin:

    fields = line.rstrip("\n").split("\t")

    if len(fields) != 4:

        continue

    try:

        movie_id = int(fields[0])

        title = fields[1]

        avg_rating = float(fields[2])

        rating_count = int(fields[3])

    except ValueError:

        continue



    if rating_count >= 100:

        sort_key = 999999999999 - int(round(avg_rating * 10000))

        print("%012d\t%d|%s|%.4f|%d" %

              (sort_key, movie_id, title, avg_rating, rating_count))

