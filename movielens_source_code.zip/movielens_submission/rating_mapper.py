
#!/usr/bin/env python

import sys



for line in sys.stdin:

    fields = line.strip().split()

    if len(fields) >= 3:

        try:

            rating = int(fields[2])

            print("%d\t1" % rating)

        except ValueError:

            continue

